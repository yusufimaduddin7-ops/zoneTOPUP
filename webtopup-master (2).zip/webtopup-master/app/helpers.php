<?php

use App\Models\Order\Order;
use App\Models\Setting\Setting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\URL;

function numberToCurrency($value)
{
    return number_format($value, 0, ',', '.');
}

function currencyToNumber($value)
{
    return (int) str_replace('.', '', $value);
}

function getSetting(?string $key = null)
{
    $setting = Cache::flexible('global:settings', [
        60,
        120,
    ], function () {
        return Setting::first()?->value ?? [];
    });

    // If no key is provided, return the whole setting object
    if (is_null($key)) {
        return $setting;
    }

    return $setting[$key] ?? null;
}

function transactionUrl(Order|string $order): string
{
    $reference = $order instanceof Order ? $order->reference : $order;

    return URL::signedRoute('transaction.show', ['order' => $reference]);
}

function transactionUpdateUrl(Order|string $order): string
{
    $reference = $order instanceof Order ? $order->reference : $order;

    return URL::signedRoute('transaction.update', ['order' => $reference]);
}
